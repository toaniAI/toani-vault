/*

   nsjail - seccomp-bpf sandboxing
   -----------------------------------------

   Copyright 2014 Google Inc. All Rights Reserved.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

*/

#ifndef NS_SANDBOX_H
#define NS_SANDBOX_H

#include <stdbool.h>

#include "nsjail.h"

namespace sandbox {

bool applyPolicy(nsj_t* nsj);
bool preparePolicy(nsj_t* nsj);
void closePolicy(nsj_t* nsj);

}  // namespace sandbox

#endif /* NS_SANDBOX_H */
